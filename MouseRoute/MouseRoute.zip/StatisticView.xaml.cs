﻿using System.Windows;

namespace MouseRoute {
    /// <summary>
    /// Description for StatisticView.
    /// </summary>
    public partial class StatisticView : Window {
        /// <summary>
        /// Initializes a new instance of the StatisticView class.
        /// </summary>
        public StatisticView() {
            InitializeComponent();
        }
    }
}